Omamail opening settings before and after
Before: c5556095. After: 839a7f2 (settings display unchanged in the final script-only adjustments).
Host: Qt 6.12.0 qmltestrunner, Linux, offscreen software renderer at scale 1.
Dimensions: 710x650 and 980x720. Light and dark are synthetic fixture palettes.
The harness uses production App/SettingsPage and Omarchy 4.5 Dropdown with stubbed shell theme and service.
No real account, provider or backend ran. These captures show the settings only, not Wayland interaction.
